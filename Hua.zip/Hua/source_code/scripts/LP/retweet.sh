#!bin/bash

python evaluation.py \
--task "LP" \
--dataset "retweet" \
--root_path ".\\datasets" \
--pretrained_model_path "Pretrain_ogbn-arxiv_computers_Physics_model" \
--num_neighbors 30 30 \
--batch_size 64 \
--capacity 300 \
--n_layers 2 \
--bias true \
--dropout 0.1 \
--embed_dim 32 \
--hidden_dim 256 \
--pretrain_epochs 3 \
--weight_decay_nc 0.0 \
--val_every 1 \
--lp_epochs 10 \
--is_load true \
--patience 5 \
--lr_lp 0.001 \
--task_model_path "retweet.pt" \
--exp_iters 1 \
--embed_dim_lp 128
