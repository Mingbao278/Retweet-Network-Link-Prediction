# dataset/retweet.py
import os
import torch
from torch_geometric.data import InMemoryDataset, Data
from torch_geometric.utils import train_test_split_edges, degree
import os.path as osp
import torch.nn as nn

class Retweet(InMemoryDataset):
    def __init__(self, root,name, transform=None, pre_transform=None):
        self.name = name
        super().__init__(root, transform, pre_transform)
        self.data, self.slices = torch.load(self.processed_paths[0])
        
    @property
    def raw_dir(self) -> str:
        return osp.join(self.root, self.name, 'raw')
    @property
    def processed_dir(self) -> str:
        return osp.join(self.root, self.name, 'processed')
    @property
    def raw_file_names(self) -> str:
        return ['train.txt']

    @property
    def processed_file_names(self):
        return ['data.pt']

    def download(self):
        # 不需要下载
        pass

    def process(self):
        all_nodes = set()
        train_edges = []
        edge_index = []
        edge_weight = []
        test_edges = []
        with open(os.path.join(self.raw_dir, 'train.txt'), 'r') as f:
            num_nodes = int(f.readline().strip())
            for line in f:
                u, v, w = map(int, line.strip().split())
                all_nodes.update([u, v])
                train_edges.append((u, v, w))
        with open(os.path.join(self.raw_dir, 'test.txt'), 'r') as f:
            for line in f:
                u, v = map(int, line.strip().split())
                all_nodes.update([u, v])
                test_edges.append((u, v))
        node2idx = {nid: i for i, nid in enumerate(sorted(all_nodes))}
        idx2node = {i: nid for nid, i in node2idx.items()}
        for u, v, w in train_edges:
            uid = node2idx[u]
            vid = node2idx[v]
            edge_index.extend([[uid, vid]]) 
            edge_weight.extend([w])      

        edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
        edge_weight = torch.tensor(edge_weight, dtype=torch.float)
        test_edge_idx = torch.tensor([
            [node2idx[u], node2idx[v]] for u, v in test_edges
        ], dtype=torch.long)

        data = Data(
            edge_index=edge_index,
            edge_attr=edge_weight,
            num_nodes=num_nodes,
            test_edge_idx=test_edge_idx,
            idx2node = torch.tensor([idx2node[i] for i in range(len(idx2node))], dtype=torch.long)
        )
        data.test_edge_index = test_edge_idx.t().contiguous()
        in_deg = degree(edge_index[1], num_nodes=num_nodes)
        out_deg = degree(edge_index[0], num_nodes=num_nodes)
        deg_feat = torch.stack([in_deg, out_deg], dim=1)
        # embed_feat = nn.Embedding(num_nodes, 32).weight.detach()
        # data.x = torch.cat([deg_feat, embed_feat], dim=1)
        data.x = deg_feat


        if self.pre_transform is not None:
            data = self.pre_transform(data)

        torch.save(self.collate([data]), self.processed_paths[0])
